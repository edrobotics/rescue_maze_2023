# Main CAD files
This is the folder for all CAD files except for the rescue kit mechanism.
